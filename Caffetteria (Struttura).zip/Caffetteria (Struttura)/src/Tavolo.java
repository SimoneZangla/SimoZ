public class Tavolo {
    private String numTavolo;
    private Cliente cliente;

    public Tavolo(String numTavolo, Cliente cliente) {
        this.numTavolo = numTavolo;
        this.cliente = cliente;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
