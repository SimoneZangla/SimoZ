import java.util.Random;

public class Cliente implements Runnable {
    private String nome;
    private Caffetteria caffetteria;

    public Cliente(String nome, Caffetteria caffetteria) {
        this.nome = nome;
        this.caffetteria = caffetteria;
    }

    public String getNome() {
        return nome;
    }

    public Caffetteria getCaffetteria() {
        return caffetteria;
    }

    @Override
    public void run() {
        try {
            caffetteria.occupaTavolo(this);
            Thread.sleep(new Random().nextLong(1000, 5000));
            caffetteria.liberaTavolo(this);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}
