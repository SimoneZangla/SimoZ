import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) {

        ExecutorService executorService = Executors.newCachedThreadPool();
        Caffetteria caffetteria = new Caffetteria("caffetteria");

        ArrayList<Cliente> clientes = new ArrayList<>(List.of(
               //Aggiungi i clienti nell'ArrayList
        ));

        for (Cliente c : clientes) {
            executorService.execute(c);
        }

        executorService.shutdown();

        while (!executorService.isTerminated());

        System.out.println("Caffetteria " + caffetteria.getName() + " chiusa.\nHa venduto " + caffetteria.getCaffeVenduti() + " caffè");
    }
}