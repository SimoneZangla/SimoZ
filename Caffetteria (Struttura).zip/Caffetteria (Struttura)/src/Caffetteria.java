import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Caffetteria {
    private String name;
    private ArrayList<Tavolo> tavoli;
    private AtomicInteger caffeVenduti;

    public Caffetteria(String name) {
        this.name = name;
        this.tavoli = new ArrayList<>(List.of(
                new Tavolo("Tavolo 1", null),
                new Tavolo("Tavolo 2", null),
                new Tavolo("Tavolo 3", null),
                new Tavolo("Tavolo 4", null)
        ));
        this.caffeVenduti = new AtomicInteger(0);
    }

    public synchronized void occupaTavolo(Cliente cliente) throws InterruptedException {
    /*Implementare la logica che controlli i tavoli occupati e faccia aspettare i thread che non trovino tavoli liberi.
        Far occupare il tavolo libero se disponibile all'oggetto cliente passato come parametro*/
        while () {
            if () {
                System.out.println("cliente " + cliente.getNome() + " in attesa");
                wait();
            }

        }

        if(){
            System.out.println("cliente " + cliente.getNome() + " si è seduto al tavolo");
        }

        //incrementa il numero di caffè venduti
    }

    public synchronized void liberaTavolo(Cliente cliente) {
        /*Implementare la logica che controlli i tavoli occupati e cerchi l'ogetto clienti tra questi,
         togliendolo e settando il tavolo occupato a null*/
        System.out.println("cliente " + cliente.getNome() + " ha lasciato il tavolo");
        notifyAll();
    }

    public int getCaffeVenduti() {
        return caffeVenduti.get();
    }

    public String getName() {
        return name;
    }
}
